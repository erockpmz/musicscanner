cd "/Users/elorson/Documents/Music Scanner"
source .venv/bin/activate

cat > patch_walkman_fullscan.py <<'PY'
from pathlib import Path

src = Path("music_library_tool_v1_1.py")
dst = Path("music_library_tool_walkman_fullscan.py")

text = src.read_text(encoding="utf-8")

old_sources = '''    "sources": [
        "/Volumes/MyMusic/MUSIC",
        "/Volumes/music/applemusic",
        "/Users/elorson/Music/My Albums",
        "/Users/elorson/Music/Rips",
        "/Users/elorson/Music/VinylStudio/My Albums",
        "/Users/elorson/Music/Music/Media.localized/Apple Music",
        "/Users/elorson/Documents/Ukeysoft/Ukeysoft Apple Music Converter",
    ],'''

new_sources = '''    "sources": [
        "/Volumes/MyMusic/MUSIC",
    ],'''

if old_sources not in text:
    raise SystemExit("Could not find sources block.")

text = text.replace(old_sources, new_sources, 1)

old_fast = '''    "fast_scan_sources": [
        "/Volumes/MyMusic/MUSIC"
    ],'''

new_fast = '''    "fast_scan_sources": [
    ],'''

if old_fast not in text:
    raise SystemExit("Could not find fast_scan_sources block.")

text = text.replace(old_fast, new_fast, 1)

old_skip = '''    "skip_hash_sources": [
        "/Volumes/MyMusic/MUSIC"
    ],'''

new_skip = '''    "skip_hash_sources": [
    ],'''

if old_skip not in text:
    raise SystemExit("Could not find skip_hash_sources block.")

text = text.replace(old_skip, new_skip, 1)

dst.write_text(text, encoding="utf-8")
print(f"Wrote {dst}")
PY
