#!/usr/bin/env python3
"""
Music Library Tool v1

Safe, inventory-only scanner for a multi-source music library.
- Reads configured source folders
- Catalogs supported audio files into SQLite
- Scores metadata quality
- Detects likely duplicates
- Flags bad/problematic files
- Serves a simple local web UI for review

No files are modified, moved, deleted, or retagged in v1.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import os
import re
import sqlite3
import sys
import threading
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from flask import Flask, jsonify, render_template_string, request
except ImportError:
    Flask = None  # type: ignore

try:
    import mutagen
    from mutagen import File as MutagenFile
    from mutagen.flac import FLAC
    from mutagen.mp3 import MP3
    from mutagen.mp4 import MP4
    from mutagen.wave import WAVE
    from mutagen.aiff import AIFF
except ImportError:
    mutagen = None  # type: ignore
    MutagenFile = None  # type: ignore
    FLAC = MP3 = MP4 = WAVE = AIFF = object  # type: ignore

APP_TITLE = "Music Library Tool v1"
SUPPORTED_EXTENSIONS = {
    ".flac", ".alac", ".m4a", ".mp4", ".aac", ".mp3", ".wav", ".wave", ".aiff", ".aif"
}
NON_AUDIO_SIDE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".cue", ".log", ".pdf", ".txt", ".xml"}
FORMAT_RANK = {
    "flac": 6,
    "alac": 5,
    "aac/m4a": 4,
    "mp3": 3,
    "wav": 2,
    "aiff": 1,
    "unknown": 0,
}
DEFAULT_CONFIG = {
    "sources": [
        "/Volumes/MyMusic/MUSIC",
        "/Volumes/music/applemusic",
        "/Users/elorson/Music/My Albums",
        "/Users/elorson/Music/Rips",
        "/Users/elorson/Music/VinylStudio/My Albums",
        "/Users/elorson/Music/Music/Media.localized/Apple Music",
        "/Users/elorson/Documents/Ukeysoft/Ukeysoft Apple Music Converter",
    ],
    "destination": "/Volumes/music/UnifiedLibrary",
    "read_only": True,
    "metadata_policy": "balanced",
    "update_album_art": True,
    "enable_online_lookup": True,
    "include_extensions": ["flac", "alac", "m4a", "mp4", "aac", "mp3", "wav", "wave", "aiff", "aif"],
    "source_priority": [
        "/Volumes/MyMusic/MUSIC",
        "/Volumes/music/applemusic",
        "/Users/elorson/Music/My Albums",
        "/Users/elorson/Music/Rips",
        "/Users/elorson/Music/VinylStudio/My Albums",
        "/Users/elorson/Music/Music/Media.localized/Apple Music",
        "/Users/elorson/Documents/Ukeysoft/Ukeysoft Apple Music Converter",
    ],
    "fast_scan_sources": [
        "/Volumes/MyMusic/MUSIC"
    ],
    "skip_hash_sources": [
        "/Volumes/MyMusic/MUSIC"
    ],
    "progress_every": 250,
}

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY,
    path TEXT NOT NULL UNIQUE,
    source_root TEXT NOT NULL,
    rel_path TEXT,
    extension TEXT,
    format_name TEXT,
    file_size INTEGER,
    modified_ts REAL,
    created_ts REAL,
    quick_hash TEXT,
    metadata_json TEXT,
    metadata_score INTEGER,
    issues_json TEXT,
    duration REAL,
    bitrate INTEGER,
    sample_rate INTEGER,
    bit_depth INTEGER,
    channels INTEGER,
    has_artwork INTEGER DEFAULT 0,
    scan_status TEXT NOT NULL,
    scanned_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS duplicate_groups (
    id INTEGER PRIMARY KEY,
    group_key TEXT NOT NULL UNIQUE,
    title TEXT,
    artist TEXT,
    album TEXT,
    duration_bucket INTEGER,
    winner_file_id INTEGER,
    review_required INTEGER DEFAULT 0,
    reason TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(winner_file_id) REFERENCES files(id)
);

CREATE TABLE IF NOT EXISTS duplicate_group_members (
    group_id INTEGER NOT NULL,
    file_id INTEGER NOT NULL,
    decision_score INTEGER,
    is_winner INTEGER DEFAULT 0,
    rationale TEXT,
    PRIMARY KEY(group_id, file_id),
    FOREIGN KEY(group_id) REFERENCES duplicate_groups(id),
    FOREIGN KEY(file_id) REFERENCES files(id)
);

CREATE INDEX IF NOT EXISTS idx_files_source_root ON files(source_root);
CREATE INDEX IF NOT EXISTS idx_files_format_name ON files(format_name);
CREATE INDEX IF NOT EXISTS idx_files_metadata_score ON files(metadata_score);
CREATE INDEX IF NOT EXISTS idx_files_scan_status ON files(scan_status);
"""

UI_TEMPLATE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>{{ title }}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 24px; }
    h1, h2 { margin-bottom: 0.3rem; }
    .muted { color: #666; }
    table { border-collapse: collapse; width: 100%; margin-top: 12px; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 14px; }
    th { background: #f5f5f5; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 16px; margin: 16px 0; }
    code { background: #f7f7f7; padding: 2px 4px; border-radius: 4px; }
    .badge { display: inline-block; background: #eee; border-radius: 999px; padding: 2px 8px; margin-right: 6px; }
  </style>
</head>
<body>
  <h1>{{ title }}</h1>
  <p class="muted">Inventory-only. No files are changed in v1.</p>

  <div class="card">
    <h2>Overview</h2>
    <p>
      <span class="badge">Files: {{ stats.total_files }}</span>
      <span class="badge">Errors: {{ stats.error_files }}</span>
      <span class="badge">Flagged: {{ stats.flagged_files }}</span>
      <span class="badge">Duplicate groups: {{ stats.duplicate_groups }}</span>
    </p>
    <p>Database: <code>{{ db_path }}</code></p>
  </div>

  <div class="card">
    <h2>Flagged files</h2>
    <table>
      <tr><th>Path</th><th>Format</th><th>Score</th><th>Issues</th></tr>
      {% for row in flagged %}
      <tr>
        <td>{{ row['path'] }}</td>
        <td>{{ row['format_name'] }}</td>
        <td>{{ row['metadata_score'] }}</td>
        <td>{{ row['issues_json'] }}</td>
      </tr>
      {% endfor %}
    </table>
  </div>

  <div class="card">
    <h2>Top duplicate groups</h2>
    <table>
      <tr><th>Title</th><th>Artist</th><th>Album</th><th>Members</th><th>Review required</th></tr>
      {% for row in duplicates %}
      <tr>
        <td>{{ row['title'] }}</td>
        <td>{{ row['artist'] }}</td>
        <td>{{ row['album'] }}</td>
        <td>{{ row['member_count'] }}</td>
        <td>{{ 'yes' if row['review_required'] else 'no' }}</td>
      </tr>
      {% endfor %}
    </table>
  </div>
</body>
</html>
"""


@dataclass
class FileRecord:
    path: str
    source_root: str
    rel_path: str
    extension: str
    format_name: str
    file_size: int
    modified_ts: float
    created_ts: float
    quick_hash: str
    metadata: Dict[str, Any]
    metadata_score: int
    issues: List[str]
    duration: Optional[float]
    bitrate: Optional[int]
    sample_rate: Optional[int]
    bit_depth: Optional[int]
    channels: Optional[int]
    has_artwork: bool
    scan_status: str


def normalize_extension(path: Path) -> str:
    return path.suffix.lower()


def is_audio_file(path: Path) -> bool:
    return normalize_extension(path) in SUPPORTED_EXTENSIONS


def safe_relpath(path: str, root: str) -> str:
    try:
        return os.path.relpath(path, root)
    except ValueError:
        return path


def format_name_from_path_and_audio(path: Path, audio: Any) -> str:
    ext = path.suffix.lower()
    if ext == ".flac":
        return "flac"
    if ext in {".m4a", ".mp4", ".aac", ".alac"}:
        if audio and audio.info and getattr(audio.info, "codec", "").lower() == "alac":
            return "alac"
        if ext == ".alac":
            return "alac"
        return "aac/m4a"
    if ext == ".mp3":
        return "mp3"
    if ext in {".wav", ".wave"}:
        return "wav"
    if ext in {".aiff", ".aif"}:
        return "aiff"
    return "unknown"


TAG_ALIASES = {
    "title": ["title", "TIT2", "©nam"],
    "artist": ["artist", "TPE1", "©ART"],
    "album": ["album", "TALB", "©alb"],
    "albumartist": ["albumartist", "TPE2", "aART"],
    "tracknumber": ["tracknumber", "TRCK", "trkn"],
    "discnumber": ["discnumber", "TPOS", "disk"],
    "date": ["date", "TDRC", "©day"],
    "genre": ["genre", "TCON", "©gen"],
}


def extract_mutagen_metadata(audio: Any) -> Tuple[Dict[str, Any], List[str]]:
    metadata: Dict[str, Any] = {}
    issues: List[str] = []
    tags = getattr(audio, "tags", None)
    if tags is None:
        issues.append("missing_tags")
        return metadata, issues

    def pick_value(keys: Sequence[str]) -> Optional[str]:
        for key in keys:
            if key not in tags:
                continue
            value = tags.get(key)
            if value is None:
                continue
            if isinstance(value, list):
                if not value:
                    continue
                first = value[0]
                if isinstance(first, tuple):
                    return str(first[0])
                return str(first)
            if hasattr(value, "text"):
                txt = getattr(value, "text", None)
                if txt:
                    return str(txt[0]) if isinstance(txt, list) else str(txt)
            return str(value)
        return None

    for canonical, aliases in TAG_ALIASES.items():
        value = pick_value(aliases)
        if value:
            metadata[canonical] = value.strip()

    artwork_present = False
    try:
        if isinstance(audio, FLAC):
            artwork_present = bool(getattr(audio, "pictures", []))
        elif isinstance(audio, MP4):
            artwork_present = bool(audio.tags.get("covr"))
        else:
            for key in ("APIC:", "APIC", "metadata_block_picture", "covr"):
                if key in tags:
                    artwork_present = True
                    break
    except Exception:
        pass
    metadata["has_artwork"] = artwork_present

    if not metadata.get("title"):
        issues.append("missing_title")
    if not metadata.get("artist"):
        issues.append("missing_artist")
    if not metadata.get("album"):
        issues.append("missing_album")
    if not metadata.get("tracknumber"):
        issues.append("missing_tracknumber")

    return metadata, issues


def parse_filename_fallback(path: Path) -> Dict[str, Any]:
    stem = path.stem
    metadata: Dict[str, Any] = {}
    m = re.match(r"^(?P<track>\d{1,2})\s*[-_. ]\s*(?P<title>.+)$", stem)
    if m:
        metadata["tracknumber"] = m.group("track")
        metadata["title"] = m.group("title").replace("_", " ").strip()
    else:
        metadata["title"] = stem.replace("_", " ").strip()

    parts = list(path.parts)
    if len(parts) >= 3:
        metadata.setdefault("album", parts[-2])
        metadata.setdefault("artist", parts[-3])
    return metadata


def metadata_score(metadata: Dict[str, Any], issues: Sequence[str]) -> int:
    score = 0
    weights = {
        "title": 20,
        "artist": 20,
        "album": 20,
        "albumartist": 10,
        "tracknumber": 10,
        "discnumber": 5,
        "date": 5,
        "genre": 5,
    }
    for key, weight in weights.items():
        if metadata.get(key):
            score += weight
    if metadata.get("has_artwork"):
        score += 5
    score -= 5 * len(issues)
    return max(score, 0)


def compute_quick_hash(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as f:
        if size <= chunk_size * 2:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
        else:
            h.update(f.read(chunk_size))
            f.seek(max(size - chunk_size, 0))
            h.update(f.read(chunk_size))
    return h.hexdigest()


def read_audio_info(path: Path) -> Tuple[Optional[Any], Dict[str, Any], List[str]]:
    if MutagenFile is None:
        raise RuntimeError("mutagen is not installed. Please install dependencies first.")

    issues: List[str] = []
    audio = MutagenFile(path)
    if audio is None:
        raise ValueError("unsupported_or_unreadable_audio")

    metadata, meta_issues = extract_mutagen_metadata(audio)
    issues.extend(meta_issues)

    fallback = parse_filename_fallback(path)
    for k, v in fallback.items():
        metadata.setdefault(k, v)

    return audio, metadata, issues




def path_is_under(path: str, roots: Sequence[str]) -> bool:
    return any(path == root or path.startswith(root + os.sep) for root in roots)


def should_fast_scan(path: Path, config: Dict[str, Any]) -> bool:
    return path_is_under(str(path), config.get("fast_scan_sources", []))


def should_skip_hash(path: Path, config: Dict[str, Any]) -> bool:
    return path_is_under(str(path), config.get("skip_hash_sources", []))


def fast_scan_audio_info(path: Path) -> Tuple[Optional[Any], Dict[str, Any], List[str]]:
    metadata = parse_filename_fallback(path)
    issues: List[str] = ["fast_scan_only"]
    if not metadata.get("title"):
        issues.append("missing_title")
    if not metadata.get("artist"):
        issues.append("missing_artist")
    if not metadata.get("album"):
        issues.append("missing_album")
    if not metadata.get("tracknumber"):
        issues.append("missing_tracknumber")
    metadata["has_artwork"] = False
    return None, metadata, issues

def path_source_priority(path: str, source_priority: Sequence[str]) -> int:
    try:
        return source_priority.index(next(root for root in source_priority if path.startswith(root)))
    except StopIteration:
        return len(source_priority) + 1
    except ValueError:
        return len(source_priority) + 1


def determine_source_root(path: str, source_roots: Sequence[str]) -> str:
    matches = [root for root in source_roots if path.startswith(root)]
    if not matches:
        return ""
    return sorted(matches, key=len, reverse=True)[0]


def scan_files(config: Dict[str, Any], db_path: str) -> None:
    logging.info("Starting inventory scan")
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(SCHEMA_SQL)
    now_iso = datetime.utcnow().isoformat() + "Z"

    scanned_files = 0
    progress_every = int(config.get("progress_every", 250) or 250)
    for source in config["sources"]:
        root = Path(source).expanduser()
        if not root.exists():
            logging.warning("Source does not exist: %s", root)
            continue
        fast_source = path_is_under(str(root), config.get("fast_scan_sources", []))
        skip_hash_source = path_is_under(str(root), config.get("skip_hash_sources", []))
        logging.info("Scanning %s%s%s", root, " [fast-scan]" if fast_source else "", " [skip-hash]" if skip_hash_source else "")
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            for filename in filenames:
                if filename.startswith("."):
                    continue
                path = Path(dirpath) / filename
                ext = normalize_extension(path)
                if ext not in SUPPORTED_EXTENSIONS:
                    continue
                try:
                    stat = path.stat()
                    if stat.st_size <= 0:
                        issues = ["zero_length_file"]
                        record = FileRecord(
                            path=str(path),
                            source_root=source,
                            rel_path=safe_relpath(str(path), source),
                            extension=ext,
                            format_name="unknown",
                            file_size=stat.st_size,
                            modified_ts=stat.st_mtime,
                            created_ts=getattr(stat, "st_birthtime", stat.st_ctime),
                            quick_hash="",
                            metadata={},
                            metadata_score=0,
                            issues=issues,
                            duration=None,
                            bitrate=None,
                            sample_rate=None,
                            bit_depth=None,
                            channels=None,
                            has_artwork=False,
                            scan_status="flagged",
                        )
                    else:
                        if should_fast_scan(path, config):
                            audio, metadata, issues = fast_scan_audio_info(path)
                        else:
                            audio, metadata, issues = read_audio_info(path)
                        fmt = format_name_from_path_and_audio(path, audio)
                        info = getattr(audio, "info", None) if audio is not None else None
                        duration = getattr(info, "length", None)
                        bitrate = getattr(info, "bitrate", None)
                        sample_rate = getattr(info, "sample_rate", None)
                        bit_depth = getattr(info, "bits_per_sample", None)
                        channels = getattr(info, "channels", None)
                        quick_hash = "" if should_skip_hash(path, config) else compute_quick_hash(path)
                        if duration is None and not should_fast_scan(path, config):
                            issues.append("missing_duration")
                        if not metadata.get("title") or metadata.get("title", "").lower() in {"track", "unknown"}:
                            issues.append("suspicious_title")
                        score = metadata_score(metadata, issues)
                        non_fatal_issues = set(issues) - {"fast_scan_only"}
                        status = "flagged" if non_fatal_issues else "ok"
                        record = FileRecord(
                            path=str(path),
                            source_root=source,
                            rel_path=safe_relpath(str(path), source),
                            extension=ext,
                            format_name=fmt,
                            file_size=stat.st_size,
                            modified_ts=stat.st_mtime,
                            created_ts=getattr(stat, "st_birthtime", stat.st_ctime),
                            quick_hash=quick_hash,
                            metadata=metadata,
                            metadata_score=score,
                            issues=sorted(set(issues)),
                            duration=duration,
                            bitrate=bitrate,
                            sample_rate=sample_rate,
                            bit_depth=bit_depth,
                            channels=channels,
                            has_artwork=bool(metadata.get("has_artwork")),
                            scan_status=status,
                        )
                except KeyboardInterrupt:
                    logging.warning("Scan interrupted by user")
                    conn.commit()
                    raise
                except Exception as exc:
                    logging.exception("Failed to scan %s", path)
                    try:
                        stat = path.stat()
                        size = stat.st_size
                        modified_ts = stat.st_mtime
                        created_ts = getattr(stat, "st_birthtime", stat.st_ctime)
                    except Exception:
                        size = 0
                        modified_ts = 0.0
                        created_ts = 0.0
                    record = FileRecord(
                        path=str(path),
                        source_root=source,
                        rel_path=safe_relpath(str(path), source),
                        extension=ext,
                        format_name="unknown",
                        file_size=size,
                        modified_ts=modified_ts,
                        created_ts=created_ts,
                        quick_hash="",
                        metadata={},
                        metadata_score=0,
                        issues=[f"scan_error:{type(exc).__name__}", str(exc)],
                        duration=None,
                        bitrate=None,
                        sample_rate=None,
                        bit_depth=None,
                        channels=None,
                        has_artwork=False,
                        scan_status="error",
                    )
                upsert_file_record(conn, record, now_iso)
                scanned_files += 1
                if scanned_files % progress_every == 0:
                    logging.info("Scanned %s audio files so far", scanned_files)
                    conn.commit()
        conn.commit()

    detect_duplicates(conn, config)
    export_reports(conn, Path(db_path).with_suffix(""))
    conn.close()
    logging.info("Scan complete")


def upsert_file_record(conn: sqlite3.Connection, record: FileRecord, now_iso: str) -> None:
    conn.execute(
        """
        INSERT INTO files (
            path, source_root, rel_path, extension, format_name, file_size, modified_ts, created_ts,
            quick_hash, metadata_json, metadata_score, issues_json, duration, bitrate, sample_rate,
            bit_depth, channels, has_artwork, scan_status, scanned_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(path) DO UPDATE SET
            source_root=excluded.source_root,
            rel_path=excluded.rel_path,
            extension=excluded.extension,
            format_name=excluded.format_name,
            file_size=excluded.file_size,
            modified_ts=excluded.modified_ts,
            created_ts=excluded.created_ts,
            quick_hash=excluded.quick_hash,
            metadata_json=excluded.metadata_json,
            metadata_score=excluded.metadata_score,
            issues_json=excluded.issues_json,
            duration=excluded.duration,
            bitrate=excluded.bitrate,
            sample_rate=excluded.sample_rate,
            bit_depth=excluded.bit_depth,
            channels=excluded.channels,
            has_artwork=excluded.has_artwork,
            scan_status=excluded.scan_status,
            scanned_at=excluded.scanned_at
        """,
        (
            record.path,
            record.source_root,
            record.rel_path,
            record.extension,
            record.format_name,
            record.file_size,
            record.modified_ts,
            record.created_ts,
            record.quick_hash,
            json.dumps(record.metadata, ensure_ascii=False),
            record.metadata_score,
            json.dumps(record.issues, ensure_ascii=False),
            record.duration,
            record.bitrate,
            record.sample_rate,
            record.bit_depth,
            record.channels,
            1 if record.has_artwork else 0,
            record.scan_status,
            now_iso,
        ),
    )


def duplicate_group_key(metadata: Dict[str, Any], duration: Optional[float], quick_hash: str) -> Optional[str]:
    title = (metadata.get("title") or "").strip().lower()
    artist = (metadata.get("artist") or "").strip().lower()
    album = (metadata.get("album") or "").strip().lower()
    duration_bucket = int(round(duration or 0))
    if quick_hash:
        return f"hash:{quick_hash}"
    if title and artist:
        return f"meta:{artist}|{album}|{title}|{duration_bucket}"
    return None


def detect_duplicates(conn: sqlite3.Connection, config: Dict[str, Any]) -> None:
    logging.info("Detecting duplicates")
    conn.execute("DELETE FROM duplicate_group_members")
    conn.execute("DELETE FROM duplicate_groups")
    rows = conn.execute("SELECT id, path, format_name, modified_ts, metadata_score, metadata_json, duration, quick_hash FROM files").fetchall()
    groups: Dict[str, List[sqlite3.Row]] = defaultdict(list)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT id, path, format_name, modified_ts, metadata_score, metadata_json, duration, quick_hash FROM files").fetchall()
    for row in rows:
        metadata = json.loads(row["metadata_json"] or "{}")
        key = duplicate_group_key(metadata, row["duration"], row["quick_hash"])
        if key:
            groups[key].append(row)

    now_iso = datetime.utcnow().isoformat() + "Z"
    for key, members in groups.items():
        if len(members) < 2:
            continue
        member_info = []
        for m in members:
            metadata = json.loads(m["metadata_json"] or "{}")
            score = decision_score(
                fmt=m["format_name"],
                metadata_score_value=m["metadata_score"],
                modified_ts=m["modified_ts"],
                path=m["path"],
                source_priority=config["source_priority"],
            )
            member_info.append((m, metadata, score))

        member_info.sort(key=lambda item: item[2], reverse=True)
        winner = member_info[0][0]
        winner_meta = member_info[0][1]
        review_required = len({item[0]["quick_hash"] for item in member_info if item[0]["quick_hash"]}) > 1
        reason = "same_hash" if all(item[0]["quick_hash"] == winner["quick_hash"] and winner["quick_hash"] for item in member_info) else "metadata_or_duration_match"

        cursor = conn.execute(
            """
            INSERT INTO duplicate_groups (
                group_key, title, artist, album, duration_bucket, winner_file_id, review_required, reason, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                key,
                winner_meta.get("title"),
                winner_meta.get("artist"),
                winner_meta.get("album"),
                int(round(member_info[0][0]["duration"] or 0)),
                winner["id"],
                1 if review_required else 0,
                reason,
                now_iso,
            ),
        )
        group_id = cursor.lastrowid
        for idx, (member, _meta, score) in enumerate(member_info):
            conn.execute(
                """
                INSERT INTO duplicate_group_members (group_id, file_id, decision_score, is_winner, rationale)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    group_id,
                    member["id"],
                    score,
                    1 if idx == 0 else 0,
                    rationale_text(member, score),
                ),
            )
    conn.commit()


def decision_score(fmt: str, metadata_score_value: int, modified_ts: float, path: str, source_priority: Sequence[str]) -> int:
    format_weight = FORMAT_RANK.get(fmt, 0) * 1_000_000_000
    meta_weight = int(metadata_score_value or 0) * 1_000_000
    time_weight = int(modified_ts or 0)
    priority_index = path_source_priority(path, source_priority)
    priority_weight = max(0, (len(source_priority) - priority_index))
    return format_weight + meta_weight + time_weight + priority_weight


def rationale_text(member: sqlite3.Row, score: int) -> str:
    return f"format={member['format_name']}; metadata_score={member['metadata_score']}; modified_ts={int(member['modified_ts'] or 0)}; score={score}"


def export_reports(conn: sqlite3.Connection, prefix: Path) -> None:
    logging.info("Exporting reports")
    prefix.parent.mkdir(parents=True, exist_ok=True)

    files_csv = prefix.with_name(prefix.name + "_files_report.csv")
    dupes_csv = prefix.with_name(prefix.name + "_duplicate_report.csv")
    flagged_csv = prefix.with_name(prefix.name + "_flagged_report.csv")

    conn.row_factory = sqlite3.Row
    file_rows = conn.execute(
        "SELECT path, source_root, format_name, file_size, modified_ts, metadata_score, issues_json, metadata_json, scan_status FROM files ORDER BY path"
    ).fetchall()
    with files_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "source_root", "format_name", "file_size", "modified_ts", "metadata_score", "issues", "metadata", "scan_status"])
        for row in file_rows:
            writer.writerow([row["path"], row["source_root"], row["format_name"], row["file_size"], row["modified_ts"], row["metadata_score"], row["issues_json"], row["metadata_json"], row["scan_status"]])

    dup_rows = conn.execute(
        """
        SELECT dg.id, dg.title, dg.artist, dg.album, dg.review_required, dg.reason,
               COUNT(dgm.file_id) AS member_count,
               SUM(CASE WHEN dgm.is_winner = 1 THEN 1 ELSE 0 END) AS winner_count
        FROM duplicate_groups dg
        JOIN duplicate_group_members dgm ON dgm.group_id = dg.id
        GROUP BY dg.id, dg.title, dg.artist, dg.album, dg.review_required, dg.reason
        ORDER BY member_count DESC, dg.artist, dg.album, dg.title
        """
    ).fetchall()
    with dupes_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["group_id", "artist", "album", "title", "member_count", "review_required", "reason"])
        for row in dup_rows:
            writer.writerow([row["id"], row["artist"], row["album"], row["title"], row["member_count"], row["review_required"], row["reason"]])

    flagged_rows = conn.execute(
        "SELECT path, format_name, metadata_score, issues_json FROM files WHERE scan_status IN ('flagged', 'error') ORDER BY metadata_score ASC, path"
    ).fetchall()
    with flagged_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "format_name", "metadata_score", "issues"])
        for row in flagged_rows:
            writer.writerow([row["path"], row["format_name"], row["metadata_score"], row["issues_json"]])


def load_config(config_path: Optional[str]) -> Dict[str, Any]:
    config = json.loads(json.dumps(DEFAULT_CONFIG))
    if config_path:
        with open(config_path, "r", encoding="utf-8") as f:
            user_config = json.load(f)
        config.update(user_config)
    return config


def create_default_config(path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2)
        f.write("\n")


def get_stats(conn: sqlite3.Connection) -> Dict[str, int]:
    total_files = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    error_files = conn.execute("SELECT COUNT(*) FROM files WHERE scan_status = 'error'").fetchone()[0]
    flagged_files = conn.execute("SELECT COUNT(*) FROM files WHERE scan_status IN ('flagged', 'error')").fetchone()[0]
    duplicate_groups = conn.execute("SELECT COUNT(*) FROM duplicate_groups").fetchone()[0]
    return {
        "total_files": total_files,
        "error_files": error_files,
        "flagged_files": flagged_files,
        "duplicate_groups": duplicate_groups,
    }


def run_web_ui(db_path: str, host: str, port: int) -> None:
    if Flask is None:
        raise RuntimeError("Flask is not installed. Please install dependencies first.")

    app = Flask(__name__)

    def get_conn() -> sqlite3.Connection:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn

    @app.route("/")
    def home() -> str:
        conn = get_conn()
        stats = get_stats(conn)
        flagged = conn.execute(
            "SELECT path, format_name, metadata_score, issues_json FROM files WHERE scan_status IN ('flagged', 'error') ORDER BY metadata_score ASC, path LIMIT 200"
        ).fetchall()
        duplicates = conn.execute(
            """
            SELECT dg.title, dg.artist, dg.album, dg.review_required, COUNT(dgm.file_id) AS member_count
            FROM duplicate_groups dg
            JOIN duplicate_group_members dgm ON dgm.group_id = dg.id
            GROUP BY dg.id, dg.title, dg.artist, dg.album, dg.review_required
            ORDER BY member_count DESC, dg.artist, dg.album, dg.title
            LIMIT 100
            """
        ).fetchall()
        html = render_template_string(UI_TEMPLATE, title=APP_TITLE, stats=stats, flagged=flagged, duplicates=duplicates, db_path=db_path)
        conn.close()
        return html

    @app.route("/api/search")
    def api_search() -> Any:
        q = request.args.get("q", "").strip().lower()
        conn = get_conn()
        if q:
            rows = conn.execute(
                "SELECT path, format_name, metadata_json, metadata_score FROM files WHERE lower(path) LIKE ? OR lower(metadata_json) LIKE ? ORDER BY metadata_score DESC LIMIT 200",
                (f"%{q}%", f"%{q}%"),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT path, format_name, metadata_json, metadata_score FROM files ORDER BY metadata_score DESC LIMIT 200"
            ).fetchall()
        payload = [dict(row) for row in rows]
        conn.close()
        return jsonify(payload)

    @app.route("/api/duplicate-groups")
    def api_duplicate_groups() -> Any:
        conn = get_conn()
        rows = conn.execute(
            """
            SELECT dg.id, dg.title, dg.artist, dg.album, dg.review_required, dg.reason,
                   COUNT(dgm.file_id) AS member_count
            FROM duplicate_groups dg
            JOIN duplicate_group_members dgm ON dgm.group_id = dg.id
            GROUP BY dg.id, dg.title, dg.artist, dg.album, dg.review_required, dg.reason
            ORDER BY member_count DESC, dg.artist, dg.album, dg.title
            LIMIT 500
            """
        ).fetchall()
        payload = [dict(row) for row in rows]
        conn.close()
        return jsonify(payload)

    app.run(host=host, port=port, debug=False)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=APP_TITLE)
    parser.add_argument("command", choices=["init-config", "scan", "serve"], help="Action to perform")
    parser.add_argument("--config", help="Path to config JSON")
    parser.add_argument("--db", default="music_inventory.db", help="SQLite database path")
    parser.add_argument("--host", default="127.0.0.1", help="Flask host for serve")
    parser.add_argument("--port", type=int, default=5055, help="Flask port for serve")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(asctime)s %(levelname)s %(message)s")

    if args.command == "init-config":
        config_path = args.config or "music_tool_config.json"
        create_default_config(config_path)
        print(f"Wrote default config to {config_path}")
        return 0

    config = load_config(args.config)

    if args.command == "scan":
        scan_files(config, args.db)
        print(f"Scan complete. Database: {args.db}")
        print(f"Reports written next to database with prefix: {Path(args.db).with_suffix('')}")
        return 0

    if args.command == "serve":
        run_web_ui(args.db, args.host, args.port)
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
